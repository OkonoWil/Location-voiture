
<?php $__env->startSection('tilte','Retours'); ?>
<?php $__env->startSection('content'); ?>

<h1 class="text-3xl font-extrabold text-blue-600 pb-3">Retours</h1>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('retours-list')->html();
} elseif ($_instance->childHasBeenRendered('w7M7Mx7')) {
    $componentId = $_instance->getRenderedChildComponentId('w7M7Mx7');
    $componentTag = $_instance->getRenderedChildComponentTagName('w7M7Mx7');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('w7M7Mx7');
} else {
    $response = \Livewire\Livewire::mount('retours-list');
    $html = $response->html();
    $_instance->logRenderedChild('w7M7Mx7', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('data'); ?>

<!-- AlpineJS -->
<script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js" defer></script>
<!-- Font Awesome -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/js/all.min.js"
    integrity="sha256-KzZiKy0DWYsnwMF+X1DvQngQ2/FxF7MF3Ff72XcpuPs=" crossorigin="anonymous"></script>
<!-- ChartJS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js"
    integrity="sha256-R4pqcOYV8lt7snxMQO/HSbVCFRPMdrhAFMH+vr9giYI=" crossorigin="anonymous"></script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('technicien.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Location\resources\views/technicien/retours/index.blade.php ENDPATH**/ ?>