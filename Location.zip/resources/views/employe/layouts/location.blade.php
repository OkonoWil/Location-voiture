@extends('employe.layouts.app')

@section('title', 'location')
@section('content')
<h1 class="text-3xl font-extrabold text-blue-600 pb-3">Locations</h1>

@yield('contenu')
@endsection