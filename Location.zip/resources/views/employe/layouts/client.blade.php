@extends('employe.layouts.app')

@section('tilte', 'client')
@section('content')
<h1 class="text-3xl font-extrabold text-blue-600 pb-3">Clients</h1>

@yield('contenu')
@endsection