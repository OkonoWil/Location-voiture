

<?php $__env->startSection('title', 'utilisateur'); ?>
<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('utilisateur.index')->html();
} elseif ($_instance->childHasBeenRendered('r6lQKRd')) {
    $componentId = $_instance->getRenderedChildComponentId('r6lQKRd');
    $componentTag = $_instance->getRenderedChildComponentTagName('r6lQKRd');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('r6lQKRd');
} else {
    $response = \Livewire\Livewire::mount('utilisateur.index');
    $html = $response->html();
    $_instance->logRenderedChild('r6lQKRd', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Location\resources\views/admin/utilisateurs/index.blade.php ENDPATH**/ ?>