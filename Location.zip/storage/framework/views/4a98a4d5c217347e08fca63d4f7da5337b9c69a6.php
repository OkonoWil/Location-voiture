

<?php $__env->startSection('tilte','Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<main class="w-full flex-grow p-6">
    <h1 class="text-3xl font-extrabold text-blue-600 pb-6">Tableau de Bord</h1>

    <div class="flex flex-wrap mt-6">
        <div class="w-full lg:w-1/2 pr-0 lg:pr-2">
            <p class="text-xl pb-3 flex items-center">
                <i class="fas fa-plus mr-3"></i> Rapport des retours
            </p>
            <div class="p-6 bg-white">
                <canvas id="chartOne" width="400" height="200"></canvas>
            </div>
        </div>
        <div class="w-full lg:w-1/2 pl-0 lg:pl-2 mt-12 lg:mt-0">
            <p class="text-xl pb-3 flex items-center">
                <i class="fas fa-check mr-3"></i> Rapport de diagnostique
            </p>
            <div class="p-6 bg-white">
                <canvas id="chartTwo" width="400" height="200"></canvas>
            </div>
        </div>
    </div>

    <div class="flex flex-wrap">
        <div class="w-full md:w-1/2 xl:w-1/3 p-6">
            <!--Metric Card-->
            <div class="bg-gradient-to-b from-blue-200 to-blue-100 border-b-4 border-blue-500 rounded-lg shadow-xl p-5">
                <div class="flex flex-row items-center">
                    <div class="flex-shrink pr-4">
                        <div class="rounded-full p-5 bg-blue-600"><i class="fas fa-users fa-2x fa-inverse"></i></div>
                    </div>
                    <div class="flex-1 text-right md:text-center">
                        <h2 class="font-bold uppercase text-gray-600">Clients</h2>
                        <p class="font-bold text-3xl"><?php echo e(Auth::user()->clients->count()); ?> <span class="text-blue-500"><i
                                    class="fas fa-caret-up"></i></span></p>
                    </div>
                </div>
            </div>
            <!--/Metric Card-->
        </div>
        <div class="w-full md:w-1/2 xl:w-1/3 p-6">
            <!--Metric Card-->
            <div
                class="bg-gradient-to-b from-yellow-200 to-pink-100 border-b-4 border-yellow-500 rounded-lg shadow-xl p-5">
                <div class="flex flex-row items-center">
                    <div class="flex-shrink pr-4">
                        <div class="rounded-full p-5 bg-yellow-600"><i
                                class="fa-solid fa-bookmark fa-2x fa-inverse"></i>
                        </div>
                    </div>
                    <div class="flex-1 text-right md:text-center">
                        <h2 class="font-bold uppercase text-gray-600">Locations</h2>
                        <p class="font-bold text-3xl"><?php echo e(Auth::user()->locations->count()); ?> <span
                                class="text-yellow-500"><i class="fas fa-exchange-alt"></i></span></p>
                    </div>
                </div>
            </div>
            <!--/Metric Card-->
        </div>
        <div class="w-full md:w-1/2 xl:w-1/3 p-6">
            <!--Metric Card-->
            <div
                class="bg-gradient-to-b from-green-200 to-green-100 border-b-4 border-green-600 rounded-lg shadow-xl p-5">
                <div class="flex flex-row items-center">
                    <div class="flex-shrink pr-4">
                        <div class="rounded-full p-5 bg-green-600"><i
                                class="fa-brands fa-cc-amazon-pay fa-2x fa-inverse"></i>
                        </div>
                    </div>
                    <div class="flex-1 text-right md:text-center">
                        <h2 class="font-bold uppercase text-gray-600">Paiements</h2>
                        <p class="font-bold text-3xl"><?php echo e(Auth::user()->paiements->count()); ?> <span
                                class="text-green-600"><i class="fas fa-caret-up"></i></span></p>
                    </div>
                </div>
            </div>
            <!--/Metric Card-->
        </div>
    </div>

    <div class="w-full mt-12">
        <p class="text-xl pb-3 flex items-center">
            <i class="fas fa-list mr-3"></i> Mes paiments récents..
        </p>
        <div class="bg-white overflow-auto">
            <table class="min-w-full bg-white">
                <thead class="bg-gray-800 text-white">
                    <tr>
                        <th class="text-center py-3 px-4 uppercase font-semibold text-sm">#</th>
                        <th class="text-center py-3 px-4 uppercase font-semibold text-sm">N° location</th>
                        <th class="text-center py-3 px-4 uppercase font-semibold text-sm">Client</th>
                        <th class="text-center py-3 px-4 uppercase font-semibold text-sm">date</th>
                        <th class="text-center py-3 px-4 uppercase font-semibold text-sm">Montant</th>
                    </tr>
                </thead>
                <tbody class="text-gray-700">
                    <?php $i = 0 ?>
                    <?php $__empty_1 = true; $__currentLoopData = $paiments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paiment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr <?php if($i%2!=0): ?>class="bg-gray-200" <?php endif; ?>>
                        <td class="text-center py-3 px-4"><?php echo e($paiment->id); ?></td>
                        <td class="text-center py-3 px-4"><?php echo e($paiment->location_id); ?></td>
                        <td class="text-center py-3 px-4"><?php echo e($paiment->location->client->name); ?></td>
                        <td class="text-center py-3 px-4"><?php echo e($paiment->datePaiement); ?></td>
                        <td class="text-center py-3 px-4"><?php echo e($paiment->montant); ?>FCFA
                        </td>
                    </tr>
                    <?php $i++ ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <span>Aucun retour enregistré...</span>
                    <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>
    <div class="w-full mt-12">
        <p class="text-xl pb-3 flex items-center">
            <i class="fas fa-list mr-3"></i> Mes locations récentes...
        </p>
        <div class="bg-white overflow-auto">
            <table class="min-w-full bg-white">
                <thead class="bg-gray-800 text-white">
                    <tr>
                        <th class="text-center py-3 px-4 uppercase font-semibold text-sm">#</th>
                        <th class="text-center py-3 px-4 uppercase font-semibold text-sm">Client</th>
                        <th class="text-center py-3 px-4 uppercase font-semibold text-sm">début</th>
                        <th class="text-center py-3 px-4 uppercase font-semibold text-sm">fin</th>
                        <th class="text-center py-3 px-4 uppercase font-semibold text-sm">Montant</th>
                        <th class="text-center py-3 px-4 uppercase font-semibold text-sm">Caution</th>
                    </tr>
                </thead>
                <tbody class="text-gray-700">
                    <?php $i = 0 ?>
                    <?php $__empty_1 = true; $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr <?php if($i%2!=0): ?>class="bg-gray-200" <?php endif; ?>>
                        <td class="text-center py-3 px-4"><?php echo e($location->id); ?></td>
                        <td class="text-center py-3 px-4"><?php echo e($location->client->name); ?></td>
                        <td class="text-center py-3 px-4"><?php echo e($location->dateDebut); ?></td>
                        <td class="text-center py-3 px-4"><?php echo e($location->dateFin); ?></td>
                        <td class="text-center py-3 px-4"><?php echo e($location->montant); ?>FCFA
                        </td>
                        <td class="text-center py-3 px-4"><?php echo e($location->caution); ?>FCFA</td>
                    </tr>
                    <?php $i++ ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <span>Aucun retour enregistré...</span>
                    <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>
    <div class="w-full mt-12">
        <p class="text-xl pb-3 flex items-center">
            <i class="fas fa-list mr-3"></i> Clients récents...
        </p>
        <div class="bg-white overflow-auto">
            <table class="min-w-full bg-white">
                <thead class="bg-gray-800 text-white">
                    <tr>
                        <th class="text-center py-3 px-4 uppercase font-semibold text-sm">#</th>
                        <th class="text-center py-3 px-4 uppercase font-semibold text-sm">Nom</th>
                        <th class="text-center py-3 px-4 uppercase font-semibold text-sm">Prénom</th>
                        <th class="text-center py-3 px-4 uppercase font-semibold text-sm">Nationalité</th>
                        <th class="text-center py-3 px-4 uppercase font-semibold text-sm">Téléphone</th>
                    </tr>
                </thead>
                <tbody class="text-gray-700">
                    <?php $i = 0 ?>
                    <?php $__empty_1 = true; $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr <?php if($i%2!=0): ?>class="bg-gray-200" <?php endif; ?>>
                        <td class="text-center py-3 px-4"><?php echo e($client->id); ?></td>
                        <td class="text-center py-3 px-4"><?php echo e($client->name); ?></td>
                        <td class="text-center py-3 px-4"><?php echo e($client->lastnName); ?></td>
                        <td class="text-center py-3 px-4"><?php echo e($client->nationalite); ?></td>
                        <td class="text-center py-3 px-4"><?php echo e($client->phone1); ?>

                        </td>
                    </tr>
                    <?php $i++ ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <span>Aucun retour enregistré...</span>
                    <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('data'); ?>
    

    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('employe.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Location\resources\views/employe/index.blade.php ENDPATH**/ ?>