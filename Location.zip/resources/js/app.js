import './bootstrap';
import swal from 'sweetalert2';
window.Swal = swal;