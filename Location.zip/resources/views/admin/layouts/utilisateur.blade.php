@extends('admin.layouts.app')

@section('title', 'utilisateur')
@section('content')
<h1 class="text-3xl font-extrabold text-blue-600 pb-3">Utilisateurs</h1>

@yield('contenu')
@endsection