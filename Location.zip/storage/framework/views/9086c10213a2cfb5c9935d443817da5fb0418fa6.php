<span class="absolute w-full bottom-10 text-white flex items-center justify-center py-4">
    <?php echo e(Auth::user()->username); ?> <span
        class="bg-green-700 ml-2 border rounded-md border-green-600 p-1"><?php echo e(Auth::user()->role->nomrole); ?></span>
</span><?php /**PATH C:\laragon\www\Location\resources\views/partials/role.blade.php ENDPATH**/ ?>