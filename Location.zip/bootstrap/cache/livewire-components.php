<?php return array (
  'client-comp' => 'App\\Http\\Livewire\\ClientComp',
  'location-comp' => 'App\\Http\\Livewire\\LocationComp',
  'paiement-comp' => 'App\\Http\\Livewire\\PaiementComp',
  'retour-comp' => 'App\\Http\\Livewire\\RetourComp',
  'utilisateur-comp' => 'App\\Http\\Livewire\\UtilisateurComp',
  'voiture-comp' => 'App\\Http\\Livewire\\VoitureComp',
);