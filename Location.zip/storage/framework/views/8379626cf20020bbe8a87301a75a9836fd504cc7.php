

<?php $__env->startSection('title', 'utilisateur'); ?>
<?php $__env->startSection('content'); ?>
<h1 class="text-3xl font-extrabold text-blue-600 pb-3">Utilisateurs</h1>

<?php echo $__env->yieldContent('contenu'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Location\resources\views/admin/layouts/utilisateur.blade.php ENDPATH**/ ?>