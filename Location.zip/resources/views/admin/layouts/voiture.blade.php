@extends('admin.layouts.app')

@section('title', 'voiture')
@section('content')
<h1 class="text-3xl font-extrabold text-blue-600 pb-3">Voitures</h1>

@yield('contenu')
@endsection