<div>

  <?php if($isBtnCreateClicked): ?>
  <?php echo $__env->make('livewire.utilisateur.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

  <?php if($isBtnEditClicked): ?>
  <?php echo $__env->make('livewire.utilisateur.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

  <?php if($isBtnListClicked): ?>
  <?php echo $__env->make('livewire.utilisateur.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>

</div>
<script>
  window.addEventListener("showSuccessMessage", event=>{ 
        Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: event.detail.Message || "Opération effectuée avec succès!",
            showConfirmButton: false,
            timer: 3000
        })

    })
    window.addEventListener("showConfirmMessage", event=>{
        Swal.fire({
            title: event.detail.title,
            text: event.detail.Message,
            icon: event.detail.icon,
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Oui, supprimez-le!',
            cancelButtonText: 'Annuler'
          }).then((result) => {
            if (result.isConfirmed) {
              window.livewire.find('<?php echo e($_instance->id); ?>').deleteUser(event.detail.data.user_id)
            }
          })

    })
    window.addEventListener("showPictureMessage", event=>{  
        Swal.fire({
            title: event.detail.title,
            text: event.detail.text,
            imageUrl: event.detail.imageUrl,
            imageWidth: 400,
            imageHeight: 200,
            imageAlt: event.detail.imageAlt,
        })
    })
</script><?php /**PATH C:\laragon\www\Location\resources\views/livewire/utilisateur/index.blade.php ENDPATH**/ ?>