

<?php $__env->startSection('title', 'location'); ?>
<?php $__env->startSection('content'); ?>
<h1 class="text-3xl font-extrabold text-blue-600 pb-3">Locations</h1>

<?php echo $__env->yieldContent('contenu'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('employe.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Location\resources\views/employe/layouts/location.blade.php ENDPATH**/ ?>