@extends('technicien.layouts.app')
@section('tilte','Retours')
@section('content')

<h1 class="text-3xl font-extrabold text-blue-600 pb-3">Retours</h1>

@yield('contenu')
@endsection